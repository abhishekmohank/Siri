import json
from chatbot import generate_response, ask_database, answerss,db_schema, common
from db import cursor
from mysql.connector import Error

db_schema=db_schema
def userinput(question):
    responses = generate_response(question)
    print("hi   ",responses)
    tool_calls = responses.tool_calls
    print(":;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;tolol",tool_calls)
    full_response = ""
    if tool_calls:
        for tool in tool_calls:
            if tool.function.name == 'ask_database':
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                query = json.loads(tool.function.arguments)["query"]
                print(query)
                result = ask_database(query)
                print("result :",result)
                # print("query ",tool_calls)
                
                if result:
                    res  = answerss(str(result))
                    an = res
                    return an
                else:
                    return "Please rephrase your question."
            else:
                return "Please rephrase your question."
    else:
        answer = common(question).choices[0].message.content
        print(common)
        return answer

# print(userinput("total number of rows"))

def suggestion(query):

    try:
        
        search_query = f"""
        SELECT name
        FROM smap
        WHERE MATCH(name)
        AGAINST('{query}' IN NATURAL LANGUAGE MODE)
        """
        cursor.execute(search_query)
        results = cursor.fetchall()
        print(results)
        suggestions = [row[0] for row in results]
    except Error as e:
        print(f"Error: {e}")
        suggestions = []
    
    return {"suggestions": suggestions}