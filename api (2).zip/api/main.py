from fastapi import FastAPI, Query
from pydantic import BaseModel
from qn import userinput, suggestion
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Adjust this to your frontend's URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class StringInput(BaseModel):
    question: str

@app.post("/echo")
def echo_string(input: StringInput):
    answer = userinput(input.question)
    return {"answer": answer}

@app.get("/suggestions")
def get_suggestions(query: str = Query(..., description="Query string for suggestions")):
    suggestions = suggestion(query)
    print(suggestions)
    return {"suggestions": suggestions}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
