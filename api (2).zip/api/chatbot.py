from db import get_column_names
from db import get_table_names
from db import cursor
from openai import OpenAI
from dotenv import load_dotenv
import os
from mysql.connector import Error
import json
load_dotenv()

def ask_database(query):
    global cursor
    cursor.execute(query)
    results = cursor.fetchall()
    results_str = results
    return results_str

def get_database_schema():
    table_names = get_table_names()
    schema = get_column_names(table_names)
    db = []
    for table in schema:
        if table['table_name'] == "sma_products" or table['table_name']=="sma_sales" or table['table_name'] == 'sma_sale_items':
            db.append(table)
    return db
table_names = get_table_names() 
db_schema = get_database_schema()
json_schema = json.dumps(db_schema, indent=2)
print(json_schema)




SQL_AGENT_FORMAT_INSTRUCTIONS = """

You are an agent designed to interact with a SQL database.only answer if the {user_question} is related to {json_schema}.If the question is ***NOT RELATED*** to {json_schema},out put the string "[]".

Database Schema:{json_schema}

## Instructions:
- Given an input question, create a syntactically correct optimised query to run, then look at the results of the query and return the answer.
-{json_schema} contains more than one table and its respective columns.From the {user_question},identify the keywords and and make the sql query wisely and accurately. 
-Use subqueries and Common Table Expressions (CTEs) to break down complex logic.
-Start with inner subqueries and build outwards to the main query.
-Use appropriate JOINs to connect data from different tables.
-Apply filtering early in the query process to reduce data volume.
-Use EXPLAIN to analyze and optimize query performance.
-Consider creating indexes on frequently queried columns.
-Avoid SELECT * and only select necessary columns.
-Use aggregations and HAVING clauses for complex conditions.
-Make that the sql query generated should be based on {json_schema},which contains the column names of the tables.
-Unless the user specifies a specific number of examples they wish to,limit it 6 or 7.
- You have access to tools for interacting with the database.
- You MUST double check your query before executing it.If you get an error while executing a query,rewrite the query and try again.
- DO NOT make any DML statements (INSERT, UPDATE, DELETE, DROP etc.)to the database.
- DO NOT MAKE UP AN ANSWER OR USE PRIOR KNOWLEDGE, ONLY USE THE RESULTS OF THE CALCULATIONS YOU HAVE DONE.
- Your response should be in Markdown. However, **when running  a SQL Query in "Action Input", do not include the markdown backticks**.
- Those are only for formatting the response, not for executing the command.
- Only use the below tools. Only use the information returned by the


## Use the following format:

User question: {user_question}.

Thoughts:
-Analyze the user's query to identify the required data points.
-Determine which tables contain the relevant data.
-Determine which tables and columns are necessary to address the question from {json_schema}.
-You may need to create subqueries to join or filter data from multiple tables.
-Optimization is crucial when dealing with large datasets.


Action:
-Plan the action, which involves constructing an appropriate SQL query.
-Break down the query into logical steps if it involves multiple operations or joins.
-If needed,create a strategy for building complex SQL queries with subqueries for your large database.

Action Input: 
-Write the SQL query or series of queries needed to retrieve the required data.
-Here's a step-by-step approach to building complex SQL queries with subqueries:

Analyze the user query:

-Identify key entities, attributes, and relationships mentioned in the query.
-Determine what kind of information is being requested (e.g., aggregations, specific records, comparisons).

Identify relevant tables:

-Based on the entities and attributes, determine which tables are likely to contain the required data.
-Consider creating a mapping of business concepts to database tables to make this process easier.


Plan the query structure:

-Determine the main query and what subqueries might be needed.
-Identify where JOINs will be necessary to connect data from different tables.

Build subqueries:

-Start with the innermost subqueries that fetch specific pieces of data.
-Use correlated subqueries when you need to reference the outer query.
-Consider using Common Table Expressions (CTEs) for complex subqueries to improve readability.

Construct the main query:

-Use the results from subqueries in the main query's SELECT, FROM, or WHERE clauses as appropriate.
-Apply necessary filters, groupings, and orderings.

Optimize the query:

-Use EXPLAIN to analyze the query execution plan.
-Consider creating indexes on frequently queried columns.
-Use appropriate JOINs (INNER, LEFT, RIGHT) based on the data requirements.
-Avoid SELECT * and only select necessary columns.
-Use WHERE clauses effectively to filter data early in the query process.

Observation: 
-Execute the query and observe the results.
-Verify that the results match the expected output based on the user's question.

Thought:
-Assess the results to confirm that they fully answer the question.
-Make any necessary adjustments if the results are incomplete or incorrect.

Final Answer: 
The final answer to the original input question.

Tools:{tools}


Few-shot examples:
1.User: "What the price of water 1l and kesar"
   SQL: SELECT name, price
        FROM sma_products
        WHERE name LIKE '%water 1l%' OR name LIKE '%kesar%';

2. User: "What the sales volume and quantity of water"
   SQL: SELECT 
    p.name AS product_name,
    SUM(si.quantity) AS total_quantity_sold,
    SUM(si.subtotal) AS total_sales_volume
    FROM 
        sma_sale_items si
    JOIN 
        sma_products p ON si.product_id = p.id
    JOIN 
        sma_sales s ON si.sale_id = s.id
    WHERE 
        p.name LIKE '%water%'
        AND s.sale_status = 'completed'  -- Assuming we only want completed sales
    GROUP BY 
        p.name
    ORDER BY 
        total_sales_volume DESC
    LIMIT 10;  -- Limiting to top 10 water products by sales volume

3.  User:"What are our top-selling product categories this year, and how do their sales compare to last year?"
    SQL:WITH current_year_sales AS (
    SELECT 
        p.category_id,
        SUM(si.quantity) AS total_quantity,
        SUM(si.subtotal) AS total_revenue
    FROM 
        sma_sales s
    JOIN 
        sma_sale_items si ON s.id = si.sale_id
    JOIN 
        sma_products p ON si.product_id = p.id
    WHERE 
        YEAR(s.date) = YEAR(CURDATE())
    GROUP BY 
        p.category_id
),
last_year_sales AS (
    SELECT 
        p.category_id,
        SUM(si.quantity) AS total_quantity,
        SUM(si.subtotal) AS total_revenue
    FROM 
        sma_sales s
    JOIN 
        sma_sale_items si ON s.id = si.sale_id
    JOIN 
        sma_products p ON si.product_id = p.id
    WHERE 
        YEAR(s.date) = YEAR(CURDATE()) - 1
    GROUP BY 
        p.category_id
)
SELECT 
    c.name AS category_name,
    cys.total_quantity AS current_year_quantity,
    cys.total_revenue AS current_year_revenue,
    lys.total_quantity AS last_year_quantity,
    lys.total_revenue AS last_year_revenue,
    (cys.total_quantity - COALESCE(lys.total_quantity, 0)) / COALESCE(lys.total_quantity, 1) * 100 AS quantity_growth_percent,
    (cys.total_revenue - COALESCE(lys.total_revenue, 0)) / COALESCE(lys.total_revenue, 1) * 100 AS revenue_growth_percent,
    (SELECT AVG(price) FROM sma_products WHERE category_id = c.id) AS avg_category_price,
    (SELECT COUNT(DISTINCT s.customer_id) 
     FROM sma_sales s 
     JOIN sma_sale_items si ON s.id = si.sale_id 
     JOIN sma_products p ON si.product_id = p.id 
     WHERE p.category_id = c.id AND YEAR(s.date) = YEAR(CURDATE())) AS unique_customers
FROM 
    sma_products p
JOIN 
    (SELECT DISTINCT category_id FROM sma_products) c ON p.category_id = c.id
LEFT JOIN 
    current_year_sales cys ON c.id = cys.category_id
LEFT JOIN 
    last_year_sales lys ON c.id = lys.category_id
WHERE 
    cys.total_revenue IS NOT NULL
ORDER BY 
    cys.total_revenue DESC
LIMIT 10;     



"""

tools = [
    {
        "type": "function",
        "function": {
            "name": "ask_database",
            "description": "Use this function to answer user questions about the database. Input should be a fully formed SQL query.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": f"""                          
                           -SQL should be written using this database schema:
                           {json_schema}
                           -Follow the {SQL_AGENT_FORMAT_INSTRUCTIONS} to make query.
                           -only answer if the user_question is related to {json_schema}.If the question is ***NOT RELATED*** to {db_schema},output a string "[]".
                           -The query should be returned in plain text, not in JSON.
                         """
                    }
                },
                "required": ["query"]
            }
        }
    }
]


api_key = os.getenv("OPENAI_API")
client = OpenAI(api_key=api_key)


def generate_response(user_question):
    response = client.chat.completions.create(
        messages=[
            {
                "role": "system",
                "content": SQL_AGENT_FORMAT_INSTRUCTIONS.format(user_question=user_question, json_schema=json_schema, tools=tools)
            },
            {
                "role": "system",
                "content": "Answer user questions by generating SQL queries. Process the {user_question} in the context of {json_schema}. If the question is not a general question like 'hi', 'how are you' etc., generate queries based on {json_schema}."
            },
            {
                "role": "user",
                "content": user_question
            }
        ],
        model="gpt-4o",
        tools=tools,
    )

    response_message = response.choices[0].message
    print(response_message)
    return response_message

def answerss(res):
    ans=client.chat.completions.create(
        messages=[
            
    {
      "role": "system",
      "content": "You are a data analyst.display the value in a humanly natural way as a sentnce.the input will be the result of an sql query.if wanted output the result as a table.example:in situations such as if the result is th combination of string and numerical values"},
    {
      "role": "user",
      "content": res 
    }
  ],
   model= "gpt-4o"

  )
    
    return ans.choices[0].message.content


def common(res):
    ans = client.chat.completions.create(
        messages=[
            {
                "role": "system",
                "content": "You are a data analyst. You assist users by providing insights, answering data-related questions, performing statistical analysis, and generating reportsz.dont want general answers. Handle each query with precision and ensure clarity in your explanations.strictly dont halucinate at any point or put your own random thoughts."
            },
            {
                "role": "user",
                "content": res 
            }
        ],
        model="gpt-4o"
    )
    return ans

# query="SELECT SUM(si.subtotal) as total_sales FROM sma_sales s JOIN sma_sale_items si ON s.id = si.sale_id JOIN sma_products p ON si.product_id = p.id WHERE p.name = 'ALSHTHAB OIL' AND s.date >= DATE_SUB(DATE_FORMAT(NOW() ,'%Y-%m-01'), INTERVAL 1 MONTH) AND s.date < DATE_FORMAT(NOW() ,'%Y-%m-01')"
# print(ask_database(query))