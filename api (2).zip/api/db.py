import mysql.connector
import re
from dotenv import load_dotenv
import os

load_dotenv()

DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')
DB_HOST = os.getenv('DB_HOST')
DB_NAME = os.getenv('DB_NAME')

cnx = mysql.connector.connect(
    host=DB_HOST,
    user=DB_USER,
    password=DB_PASSWORD,
    database=DB_NAME
)
cursor = cnx.cursor()


def get_table_names():
    global cursor
    table_names = []
    cursor.execute("SHOW TABLES")
    for table in cursor:
        table_names.append(table[0])
    return table_names

def get_column_names(table_name):
    column_names = []
    global cursor 
    valid_table_name = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')
    
    for table_names in table_name:
        # Validate that table_name is a string and matches the valid pattern
        if not isinstance(table_names, str) or not valid_table_name.match(table_names):
            print(f"Invalid table name found: {table_names}") 
            raise ValueError(f"Invalid table name: {table_names}")
        
        # Use formatted string with sanitized table name
        cursor.execute(f"DESCRIBE `{table_names}`")
        column_name = []
        for column in cursor:
            column_name.append(column[0])
        column={"table_name":table_names,"column_name": column_name
        }
        column_names.append(column)
    return column_names
